# CMD + T Bookmark
This extension will replace your new page with bookmark search. It searches all your bookmark and present relevant result...

## Download it
https://chrome.google.com/webstore/detail/cldjjoblahbifbhbdjmjimglomfojckk


## Screenshots
![1.png](./screenshot/1.png)
![2.png](./screenshot/2.png)
